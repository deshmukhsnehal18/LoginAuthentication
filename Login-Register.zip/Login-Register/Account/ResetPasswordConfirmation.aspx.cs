﻿using System.Web.UI;

namespace Login_Register.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}