﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
//using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace Login_Register
{
    public partial class Gridview_display : System.Web.UI.Page
    {
        string constr = Convert.ToString(ConfigurationManager.ConnectionStrings["Conn"]);
        protected void Page_Load(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void BindGrid(string sortExpression = null)
        {

            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlDataAdapter sqlda = new SqlDataAdapter("Select EmployeeID,EmpName,CAST(DateOfBirth AS DATE) AS DateOfBirth,Qualification,CAST(JoinDate AS DATE) AS JoinDate ,Salary, Designation, Hobbies From employee", con);
            DataTable dt = new DataTable();
            sqlda.Fill(dt);

            if (sortExpression != null)
            {
                DataView dv = dt.AsDataView();
                this.SortDirection = this.SortDirection == "ASC" ? "DESC" : "ASC";

                dv.Sort = sortExpression + " " + this.SortDirection;
                grvEmployee.DataSource = dv;
            }
            else
            {
                grvEmployee.DataSource = dt;
            }


            // grvEmployee.DataSource = dt;
            grvEmployee.DataBind();
            con.Close();


        }
        private string SortDirection
        {
            get { return ViewState["SortDirection"] != null ? ViewState["SortDirection"].ToString() : "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }


        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", "EmployeeInfo.xls"));
                Response.ContentType = "application/ms-excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter ht = new HtmlTextWriter(sw);
                grvEmployee.RenderControl(ht);
                Response.Write(sw.ToString());
                Response.End();
            }
            catch (Exception ex)
            {

            }
        }

        protected void grvEmployee_Sorting(object sender, GridViewSortEventArgs e)
        {
            this.BindGrid(e.SortExpression);
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            string selectedValue = "";




            if (txtEmpName.Text == "")
            {
                alert("Please enter Employee Name");
                return;
            }

            if (txtqualification.Text == "")
            {
                alert("Please enter Qualification");
                return;
            }


            if (txtJoiningDate.Text == "")
            {
                alert("Please enter joining date");
                return;
            }

            if (txtdateofBirth.Text == "")
            {
                alert("Please enter Date Of Birth");
                return;
            }

            if (txtJoiningDate.Text == "")
            {
                alert("Please enter Joining date");
                return;
            }



            if (txtSalary.Text == "")
            {
                alert("Please enter salary");
                return;
            }

            foreach (ListItem item in chkHobbies.Items)
            {
                if (item.Selected)
                {
                    selectedValue = selectedValue + " " + item.Value + ",";
                }
            }

            if (selectedValue != "")
            {
                selectedValue = selectedValue.Remove(selectedValue.Length - 1);
            }

            DateTime dtdateofBirth = new DateTime();
            DateTime dtJoiningDate = new DateTime();
            dtdateofBirth = Convert.ToDateTime(txtdateofBirth.Text);
            dtJoiningDate = Convert.ToDateTime(txtJoiningDate.Text);


            SqlConnection con = new SqlConnection(constr);
            con.Open();

            SqlDataAdapter sqlda = new SqlDataAdapter("Select 1 From employee where empname='"+ txtEmpName.Text + "'", con);
            DataTable dt = new DataTable();
            sqlda.Fill(dt);

            if (dt != null && dt.Rows.Count > 0)
            {
                alert("Employee name already exists");
                return;
            }


            string query = "insert into employee values('" + txtEmpName.Text + "','" + dtdateofBirth + "','" + txtqualification.Text + "','" + dtJoiningDate + "','" + txtSalary.Text + "','" + txtDesignation.Text + "','" + selectedValue + "',getdate())";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            DataBind();
            Clear();
        }

        private void Clear()
        {
            txtEmpName.Text = "";
            txtJoiningDate.Text = "";
            txtqualification.Text = "";
            txtSalary.Text = "";
            txtDesignation.Text = "";
            txtdateofBirth.Text = "";
        }
        public void alert(string message)
        {

            
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("<script type = 'text/javascript'>");
            sb.Append("window.onload=function(){");
            sb.Append("alert('");
            sb.Append(message);
            sb.Append("')};");
            sb.Append("</script>");
            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
        }
    }
}