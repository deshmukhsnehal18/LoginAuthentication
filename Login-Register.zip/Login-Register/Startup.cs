﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Login_Register.Startup))]
namespace Login_Register
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
